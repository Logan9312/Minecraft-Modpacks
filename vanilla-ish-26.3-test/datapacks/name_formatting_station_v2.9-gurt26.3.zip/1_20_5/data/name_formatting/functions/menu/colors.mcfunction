#
# Description:	menu for colors
# Called by:	name_formatting:menu/format_name_trigger
# Entity @s:	player
#
tellraw @s [{"text":""},{"text":"[ ","color": "yellow"},{"text":"none","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 199" }, "color": "yellow"}," ",{"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 200" }, "color": "#f9fffe"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 201" }, "color": "#f38baa"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 202" }, "color": "#b02e26"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 203" }, "color": "#f9801d"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 204" }, "color": "#fed83d"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 205" }, "color": "#80c71f"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 206" }, "color": "#5e7c16"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 207" }, "color": "#169c9c"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 208" }, "color": "#3ab3da"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 209" }, "color": "#3c44aa"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 210" }, "color": "#8932b8"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 211" }, "color": "#c74ebd"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 212" }, "color": "#835432"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 213" }, "color": "#9d9d97"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 214" }, "color": "#474f52"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 215" }, "color": "#1d1d21"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 216" }, "color": "black"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 217" }, "color": "dark_gray"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 218" }, "color": "gray"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 219" }, "color": "white"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 220" }, "color": "red"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 221" }, "color": "yellow"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 222" }, "color": "green"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 223" }, "color": "aqua"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 224" }, "color": "blue"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 225" }, "color": "light_purple"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 226" }, "color": "dark_red"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 227" }, "color": "gold"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 228" }, "color": "dark_green"}, {"text":"■","clickEvent": { "action": "run_command", "value": "/trigger FormatName set 229" }, "color": "dark_aqua"}, \
        {\
            "text":"■",\
            "clickEvent": { \
                "action": "run_command", \
                "value": "/trigger FormatName set 230" \
            }, \
            "color": "dark_blue"\
        }, \
        {\
            "text":"■",\
            "clickEvent": { \
                "action": "run_command", \
                "value": "/trigger FormatName set 231" \
            }, \
            "color": "dark_purple"\
        },\
        {\
            "text":" "\
        },\
        {\
            "text":"Custom",\
            "clickEvent": { \
                "action": "suggest_command", \
                "value": "/trigger CustomNameColor set " \
            }, \
            "color": "yellow"\
        },\
        {\
            "text":" ]",\
            "color": "yellow"\
        }\
    ]