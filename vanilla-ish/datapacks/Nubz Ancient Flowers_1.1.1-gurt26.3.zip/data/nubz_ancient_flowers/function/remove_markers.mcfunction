
execute as @e[name=TorchflowerChargeMarker,type=marker] at @s unless block ~ ~ ~ #nubz_ancient_flowers:torchflowers run function nubz_ancient_flowers:torchflower/remove_torchflower
execute as @e[name=PitcherWaterMarker,type=marker] at @s unless block ~ ~ ~ #nubz_ancient_flowers:pitcher_plants run kill @s