scoreboard objectives add flower_ray_steps dummy
scoreboard objectives add flower_ray_success dummy

scoreboard objectives add torchflower_charge dummy
scoreboard objectives add tochflower_max_charge dummy

scoreboard objectives add pitcher_plant_filled dummy
scoreboard objectives add pitcher_plant_filled_water dummy
scoreboard objectives add pitcher_plant_filled_mundane dummy
scoreboard objectives add pitcher_plant_filled_thick dummy
scoreboard objectives add pitcher_plant_filled_awkward dummy
scoreboard objectives add pitcher_plant_filled_poison dummy
scoreboard objectives add pitcher_plant_awkward_disabled dummy

advancement revoke @a only nubz_ancient_flowers:check_torchflower_placement
advancement revoke @a only nubz_ancient_flowers:check_torchflower_pot