#remove 1 bottle from the players inventory
clear @s glass_bottle 1

#fill a glass bottle with water from the Pitcher plant
give @s minecraft:potion[potion_contents={potion:"minecraft:thick"}]




