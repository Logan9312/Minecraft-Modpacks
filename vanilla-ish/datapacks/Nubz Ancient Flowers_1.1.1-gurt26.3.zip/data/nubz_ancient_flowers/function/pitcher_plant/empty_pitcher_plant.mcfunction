scoreboard players set @s pitcher_plant_filled 0
scoreboard players set @s pitcher_plant_filled_awkward 0
scoreboard players set @s pitcher_plant_filled_mundane 0
scoreboard players set @s pitcher_plant_filled_poison 0
scoreboard players set @s pitcher_plant_filled_thick 0
scoreboard players set @s pitcher_plant_filled_water 0

function nubz_ancient_flowers:observer_update

playsound minecraft:item.bucket.empty_lava player @a ~ ~ ~ 0.75 1.4