scoreboard players reset @s leafDec.oakL
scoreboard players reset @s leafDec.oakS
scoreboard players reset @s leafDec.spruceL
scoreboard players reset @s leafDec.spruceS
scoreboard players reset @s leafDec.birchL
scoreboard players reset @s leafDec.birchS
scoreboard players reset @s leafDec.jungleL
scoreboard players reset @s leafDec.jungleS
scoreboard players reset @s leafDec.acaciaL
scoreboard players reset @s leafDec.acaciaS
scoreboard players reset @s leafDec.darkOakL
scoreboard players reset @s leafDec.darkOakS
scoreboard players reset @s leafDec.mangroveL
scoreboard players reset @s leafDec.mangroveS
scoreboard players reset @s leafDec.cherryL
scoreboard players reset @s leafDec.cherryS
scoreboard players reset @s leafDec.paleL
scoreboard players reset @s leafDec.paleS
scoreboard players reset @s leafDec.poplarL
scoreboard players reset @s leafDec.poplarW
scoreboard players reset @s leafDec.poplarSL
scoreboard players reset @s leafDec.poplarSW
scoreboard players reset @s leafDec.poplarR
scoreboard players reset @s leafDec.poplarO
scoreboard players reset @s leafDec.poplarY
scoreboard players set #steps leafDec.dummy 50
function fast_leaf_decay:raycast